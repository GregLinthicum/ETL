# -*- coding: utf-8 -*-
"""
Created on Sun Nov 28 14:19:23 2021

@author: GregBurlington
"""

import sys
# main program starts here
if __name__ == '__main__':
  program = sys.argv[0]
  print("Program running is:", program)