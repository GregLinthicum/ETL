# -*- coding: utf-8 -*-
"""
Created on Sun Nov 28 14:21:15 2021

@author: GregBurlington
"""
"""
In Spyder, we can add the extra arguments by:
Run -> Configure
Check Command line options then enter “hello world” in the text field
Click on OK
OR you can run directly from the terminal window as python sysargs.py hello world
Now run the script and you will see the arguments have been passed into your script.

commandline entered in Spyder: Bonjour Mesdames et Monsieurs
"""
import sys
# main program starts here
if __name__ == '__main__':
    program = sys.argv[0]
    print("Program running is:", program)
    #Now check for extra arguments
    if (len(sys.argv) >= 2):
        for a in range(len(sys.argv)):
            print("oArguments:", a, ": ", sys.argv[a])