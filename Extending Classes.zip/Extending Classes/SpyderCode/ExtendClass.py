# -*- coding: utf-8 -*-
"""
Go to your python shell

pip install findspark

import findspark
findspark.init()
"""
import sys
import findspark
findspark.init('C:\SparkInstallation\spark-3.2.0-bin-hadoop3.2')
from pyspark.sql import SparkSession
from pyspark.sql.dataframe import DataFrame
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

## sys.setProperty("hadoop.home.dir", "C:\\SparkInstallation\\spark-3.2.0-bin-hadoop3.2\\hadoop\\bin")


spark = SparkSession.builder.getOrCreate()


class MyClass(DataFrame):
   def __init__(self,df):
      super().__init__(df._jdf, df.sql_ctx)
      self._df = df

   def add_column3(self):
      #Add column1 to dataframe received
      newDf=self._df.withColumn("col3",F.lit(3))
      return MyClass(newDf)

   def add_column4(self):
      #Add column2 to dataframe received
      newDf=self._df.withColumn("col4",F.lit(4))
      return MyClass(newDf)


df = spark.createDataFrame([("a",1), ("b",2)], ["col1","col2"])
df.show()
myobj = MyClass(df)
df1 = myobj.add_column3().add_column4()
df1.show()
df2 = df1.drop().show()
myobj.add_column3().add_column4().na.drop().show() #na is Spark DataFrame api function, which is used to drop or fill null values.
