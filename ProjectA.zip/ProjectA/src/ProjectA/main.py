import ModulePerson2
from ModulePerson2 import Person2
from ModulePerson2 import my_sum

print('from main')

print (my_sum(23, 1003))

Person2(70,79).get_data()