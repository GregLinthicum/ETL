__all__ = ['Person2', 'age', 'my_sum']


def my_sum(x, y):
    """ calculates the sum of x and y.
    Parameters:
    x (int): a number
    y (int): another number
    Returns:
    int: sum of x and y
    """
    return x+y

class Person2:
    "This is a Person Two class"
    age = 30
    lengthOfMustache = 12

    def greet(self):
        print('Bonjour')
        
    def __init__(self, r=0, i=0):
        self.real = r
        self.imag = i

    def get_data(self):
        print(f'{self.real}+{self.imag}j')
        
# Output: 30
print('Age: ', Person2.age)
print('Mustaches: %d cm' % Person2.lengthOfMustache)

# Output: <function Person.greet>
print(Person2.greet)

# Output: "This is a Second person class"
print(Person2.__doc__)

harry = Person2()
harry.greet()

ppp = Person2(100,49).get_data()

print (my_sum(3, 13))
