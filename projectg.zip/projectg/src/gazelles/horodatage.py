import datetime

date_string = '2021-09-01T15:27:05.004573 +0530' ## read from DynamiDB
dt = datetime.datetime.now()

def writeToDynamoDB (newTimestamp):
	tss = newTimestamp.strftime("%Y-%m-%dT%H:%M:%S.00000000Z")
	## write to DynamoDB
	return tss
    
def definiHorodatage():
    newTimestamp = datetime.datetime.now()
    currentTimestampString = writeToDynamoDB (newTimestamp )
    return currentTimestampString
