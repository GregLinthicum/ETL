__all__ = ['Person', 'age', 'ma_somme']


def ma_somme(x, y):
    return x+y

class Person:
    "Ceci est une classe de deuxième personne"
    age = 30
    laLongueurDesMoustaches = 12

    def saluer(self):
        print('Bonjour')
        
    def __init__(self, r=0, i=0):
        self.real = r
        self.imag = i

    def get_data(self):
        print(f'{self.real}+{self.imag}j')
        

print('Age: ', Person.age)
print('Mustaches: %d cm' % Person.laLongueurDesMoustaches)


print(Person.saluer)


print(Person.__doc__)

harry = Person()
harry.saluer()

ppp = Person(89,49).get_data()

print (ma_somme(3, 13))
