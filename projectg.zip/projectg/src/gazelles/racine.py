import os
import pathlib
import os.path
from pathlib import Path

def obtenirLeContenuDuFichierReadme():
    approot ='.'
    readmedir ='.'
    curdir='.'
    finaldir='.'
    long_description='La description en README.md n\'a pas été fournie'
    try:
        approot = os.path.dirname(os.path.abspath(__file__))
    except:
        import sys
        approot = os.path.dirname(os.path.abspath(sys.argv[0]))
        
    try:
        readmedir = pathlib.Path(__file__).parent.resolve()
    except:
        readmedir ='.'
        
    try:
        finaldir = approot
        print('Le Répertoire fichier README est: ', approot)
        long_description = Path(approot+'/README.md').read_text(encoding='utf-8')
    except:
        try:
            finaldir = readmedir
            print('Le Répertoire fichier README est: ', readmedir)
            long_description = Path(readmedir+'/README.md').read_text(encoding='utf-8')
        except: 
            try:
                curdir = os.getcwd()
                finaldir = curdir
                print('Le Répertoire fichier README est: ', curdir)
                long_description = Path(curdir+'/README.md').read_text(encoding='utf-8')
            except:
                print( 'Ni ', readmedir ,' ni ' , approot ,  ' ni ', curdir,  ' contient README.md' )
                finaldir = ' pas trouvé '
        
        print('Le Répertoire de fichier README  finnalement est: ', finaldir)
        return long_description
        