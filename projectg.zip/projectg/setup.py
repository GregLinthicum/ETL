from setuptools import setup, find_packages
import pathlib
import os
import os.path
from pathlib import Path

def obtenirLeContenuDuFichierReadme():
    approot ='.'
    readmedir ='.'
    curdir='.'
    finaldir='.'
    long_description='La description en README.md n\'a pas été fournie'
    try:
        approot = os.path.dirname(os.path.abspath(__file__))
    except:
        import sys
        approot = os.path.dirname(os.path.abspath(sys.argv[0]))
        
    try:
        readmedir = pathlib.Path(__file__).parent.resolve()
    except:
        readmedir ='.'
        
    try:
        finaldir = approot
        print('Le Répertoire fichier README est: ', approot)
        long_description = Path(approot+'/README.md').read_text(encoding='utf-8')
    except:
        try:
            finaldir = readmedir
            print('Le Répertoire fichier README est: ', readmedir)
            long_description = Path(readmedir+'/README.md').read_text(encoding='utf-8')
        except: 
            try:
                curdir = os.getcwd()
                finaldir = curdir
                print('Le Répertoire fichier README est: ', curdir)
                long_description = Path(curdir+'/README.md').read_text(encoding='utf-8')
            except:
                print( 'Ni ', readmedir ,' ni ' , approot ,  ' ni ', curdir,  ' contient README.md' )
                finaldir = ' pas trouvé '
        
        print('Le Répertoire de fichier README  finnalement est: ', finaldir)
        return long_description
        

# Get the long description from the README file
long_description = obtenirLeContenuDuFichierReadme()

# Arguments marked as "Required" below must be included for upload to PyPI.
# Fields marked as "Optional" may be commented out.

setup(
    name='gazelles',  # Required
    version='2.0.2',  # Required
    description='Projet Gazelles et Oryx en AWS Glue et Spark',  # Optional
    long_description=long_description,  # Optional
    long_description_content_type='text/markdown',  # Optional (see note above)
    author='Greg Bobrowski, MFA ', # Optional
    author_email='Greg.Bobrowski-ext@mfa.gouv.qc.ca',  # Optional
    # For a list of valid classifiers, see https://pypi.org/classifiers/
    classifiers=[  # Optional
        # How mature is this project? Common values are
        #   3 - Alpha
        #   4 - Beta
        #   5 - Production/Stable
        'Development Status :: 3 - Alpha',

        # Indicate who your project is intended for
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Build Tools',

        # Pick your license as you wish
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        "Programming Language :: Python :: 3.10",
        'Programming Language :: Python :: 3 :: Only',
    ],
    keywords='sample, setuptools, development',  # Optional
    package_dir={'': 'src'},  # Optional
    packages=find_packages(where='src'),  # Required
    python_requires='>=3.7, <4',
    install_requires=['peppercorn', 'zipp', 'urllib3'] , # Optional
)
